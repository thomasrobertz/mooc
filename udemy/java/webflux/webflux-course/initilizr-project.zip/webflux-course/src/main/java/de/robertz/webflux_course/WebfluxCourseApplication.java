package de.robertz.webflux_course;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxCourseApplication.class, args);
	}

}
