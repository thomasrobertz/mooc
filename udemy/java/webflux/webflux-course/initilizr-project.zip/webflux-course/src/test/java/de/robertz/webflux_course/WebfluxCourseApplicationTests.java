package de.robertz.webflux_course;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
