module.exports = handlers => ({
  method: 'POST',
  path: '/pizza',
  handler: handlers.pizza
})
