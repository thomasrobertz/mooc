module.exports = function (username, passwordHash) {
  this.username = username
  this.passwordHash = passwordHash
}
